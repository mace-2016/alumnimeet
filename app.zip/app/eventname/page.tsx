"use client";

import React, { useState } from "react";
import Link from "next/link";
import { PhoneInput } from "react-international-phone";
import "react-international-phone/style.css";

import {
  GraduationCap,
  Sparkles,
  Send,
  CheckCircle,
  Loader2,
  User,
  Mail,
  Home,
} from "lucide-react";

export default function EventNamePage() {
  const [eventName, setEventName] = useState("");
  const [submitterName, setSubmitterName] = useState("");
  const [phone, setPhone] = useState("");
  const [emailId, setEmailId] = useState("");
  const [classYear, setClassYear] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!phone || phone.replace(/\D/g, "").length < 8) {
      setStatus("error");
      return;
    }

    setStatus("submitting");

    const GOOGLE_FORM_ACTION_URL =
      "https://docs.google.com/forms/d/e/1FAIpQLSfnoLHOkLXWmxgspb4-te3c5UqdgieNhXUjEgRmKLBnm9FCwA/formResponse";

    const formData = new FormData();
    formData.append("entry.1424149438", eventName);
    formData.append("entry.520789514", submitterName);
    formData.append("entry.1669338403", phone);
    formData.append("entry.797828323", classYear);

    if (emailId.trim()) {
      formData.append("entry.1841428817", emailId.trim());
    }

    try {
      await fetch(GOOGLE_FORM_ACTION_URL, {
        method: "POST",
        mode: "no-cors",
        body: formData,
      });

      setStatus("success");
    } catch (error) {
      console.error("Submission error:", error);
      setStatus("error");
    }
  };

  const resetForm = () => {
    setEventName("");
    setSubmitterName("");
    setPhone("");
    setEmailId("");
    setClassYear("");
    setStatus("idle");
  };

  return (
    <div className="min-h-[calc(100vh-80px)] bg-slate-50 flex items-center justify-center p-4 py-12">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
        <div className="p-6 sm:p-8">
          {status === "success" ? (
            <div className="text-center py-8">
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>

              <h2 className="text-xl font-bold text-slate-800 mb-2">Suggestion Sent!</h2>
              <p className="text-slate-600 mb-8">
                Thanks for your input! We can&apos;t wait to see you at the event.
              </p>

              <div className="space-y-4 flex flex-col items-center">
                <Link
                  href="/"
                  className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-all active:scale-[0.98]"
                >
                  <Home className="mr-2 h-4 w-4" />
                  Go back to home
                </Link>

                <button
                  type="button"
                  onClick={resetForm}
                  className="text-indigo-600 font-medium hover:text-indigo-800 transition-colors text-sm"
                >
                  Submit another idea
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="text-center mb-8">
                <h1 className="text-2xl font-bold text-[#1f295a] mb-2">
                  Event Name Suggestion
                </h1>
                <p className="text-slate-500 text-sm">
                  Help us brand our Class of 2016 grand reunion!
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-1">
                  <label className="block text-sm font-semibold text-slate-700">
                    Suggested Event Name <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Sparkles className="h-5 w-5 text-slate-400" />
                    </div>
                    <input
                      required
                      type="text"
                      value={eventName}
                      onChange={(e) => setEventName(e.target.value)}
                      className="block w-full pl-10 pr-3 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 bg-slate-50 hover:bg-white outline-none"
                      placeholder="e.g., MACE Reminisce '26"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="block text-sm font-medium text-slate-600">
                      Your Name <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-4 w-4 text-slate-400" />
                      </div>
                      <input
                        required
                        type="text"
                        value={submitterName}
                        onChange={(e) => setSubmitterName(e.target.value)}
                        className="block w-full pl-9 pr-3 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-600 outline-none text-sm"
                        placeholder="John Doe"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-sm font-medium text-slate-600">
                      Class <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <GraduationCap className="h-4 w-4 text-slate-400" />
                      </div>
                      <select
                        required
                        value={classYear}
                        onChange={(e) => setClassYear(e.target.value)}
                        className="block w-full pl-9 pr-10 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-600 outline-none text-sm appearance-none bg-slate-50"
                      >
                        <option value="" disabled>
                          Select...
                        </option>
                        <option value="Mech A">Mech A</option>
                        <option value="Mech B">Mech B</option>
                        <option value="EEE A">EEE A</option>
                        <option value="EEE B">EEE B</option>
                        <option value="EC">EC</option>
                        <option value="CS">CS</option>
                        <option value="Civil A">Civil A</option>
                        <option value="Civil B">Civil B</option>
                      </select>
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                        <svg
                          className="h-4 w-4 text-slate-400"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M19 9l-7 7-7-7"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
  <label className="block text-sm font-medium text-slate-600">
    Contact Number (WhatsApp) <span className="text-red-500">*</span>
  </label>

  <div className="rounded-lg border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-indigo-600 focus-within:border-indigo-600 px-3">
    <PhoneInput
      defaultCountry="in"
      value={phone}
      onChange={(value) => setPhone(value)}
      inputClassName="!w-full !border-0 !bg-transparent !text-sm focus:!outline-none focus:!shadow-none"
      countrySelectorStyleProps={{
        buttonClassName: "!border-0 !bg-transparent !shadow-none hover:!bg-transparent !mr-2",
        dropdownStyleProps: {
          className: "!z-[9999]",
        },
      }}
    />
  </div>
</div>

                <div className="space-y-1">
                  <label className="block text-sm font-medium text-slate-600">
                    Email Id <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-4 w-4 text-slate-400" />
                    </div>
                    <input
                      type="email"
                      value={emailId}
                      onChange={(e) => setEmailId(e.target.value)}
                      className="block w-full pl-9 pr-3 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-600 outline-none text-sm bg-slate-50"
                      placeholder="name@example.com"
                    />
                  </div>
                </div>

                {status === "error" && (
                  <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    Please enter a valid phone number or try submitting again.
                  </div>
                )}

                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="w-full flex justify-center items-center py-3.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-70 transition-all active:scale-[0.98]"
                >
                  {status === "submitting" ? (
                    <Loader2 className="animate-spin h-5 w-5" />
                  ) : (
                    <>
                      Submit <Send className="ml-2 h-4 w-4" />
                    </>
                  )}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}