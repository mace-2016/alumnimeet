"use client";

import React from "react";
import Link from "next/link";
import { Calendar, MapPin, ArrowRight, School, Star } from "lucide-react";

export default function HomePage() {
  return (
    <div className="bg-white">
      <section className="relative py-24 px-6 overflow-hidden bg-slate-50">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-20 left-10 w-64 h-64 bg-indigo-400 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-400 rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 text-xs font-bold uppercase tracking-wider mb-6">
            <Star className="w-3 h-3" />
            Official Alumni Portal
          </div>

          <h1 className="text-5xl md:text-6xl font-extrabold text-[#1f295a] leading-tight mb-6">
            A Decade of Memories, <br />
            <span className="text-indigo-600">A Lifetime of Connections.</span>
          </h1>

          <p className="text-lg text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
            Welcome back, Class of 2016! This is our dedicated space for staying
            connected, organizing meetups, and planning the grand reunion we've
            all been waiting for.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/eventname"
              className="px-8 py-4 bg-indigo-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-200 hover:bg-indigo-700 hover:-translate-y-1 transition-all flex items-center justify-center gap-2"
            >
              Name Our Next Event <ArrowRight className="w-5 h-5" />
            </Link>

            <button className="px-8 py-4 bg-white text-slate-700 border border-slate-200 rounded-xl font-bold text-lg hover:bg-slate-50 transition-all">
              Join WhatsApp Group
            </button>
          </div>
        </div>
      </section>

      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-[#1f295a] mb-4">
            What's Happening
          </h2>
          <div className="h-1.5 w-20 bg-indigo-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-8 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-6">
              <Calendar className="text-blue-600 w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-slate-800">
              Reunion 2026
            </h3>
            <p className="text-slate-500 leading-relaxed">
              Planning is officially underway for our 10th-anniversary
              celebration. We need your creative ideas to make it legendary!
            </p>
          </div>

          <div className="p-8 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-6">
              <MapPin className="text-green-600 w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-slate-800">
              Local Meetups
            </h3>
            <p className="text-slate-500 leading-relaxed">
              Connecting batchmates in Kochi, Bangalore, Dubai, and beyond. Find
              your local city group and never miss a casual hangout.
            </p>
          </div>

          <div className="p-8 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-6">
              <School className="text-purple-600 w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-slate-800">
              Giving Back
            </h3>
            <p className="text-slate-500 leading-relaxed">
              From mentorship programs to campus infrastructure support, our
              batch is committed to supporting MACE excellence.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}