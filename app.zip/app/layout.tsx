import "./globals.css";
import React from "react";
import Link from "next/link";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased font-sans">
        <div className="min-h-screen bg-slate-50 flex flex-col">
          <nav className="border-b border-slate-100 py-4 px-6 bg-white/80 backdrop-blur-md sticky top-0 z-50">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
              <Link href="/" className="flex items-center gap-3">
                <img
                  src="https://mace.ac.in/wp-content/uploads/2025/01/logo-2.svg"
                  alt="MACE Logo"
                  className="h-10 w-auto"
                />
                <div className="hidden sm:block h-8 w-px bg-slate-200 mx-2"></div>
                <span className="hidden sm:block font-bold text-[#1f295a] text-lg">
                  Class of 2016
                </span>
              </Link>

              <div className="flex gap-6 items-center">
                <Link
                  href="/"
                  className="text-slate-600 hover:text-indigo-600 transition-colors font-medium text-sm"
                >
                  Home
                </Link>
                <Link
                  href="/eventname"
                  className="text-white bg-indigo-600 px-4 py-2 rounded-full text-sm font-bold hover:bg-indigo-700 transition-all shadow-md"
                >
                  Join Planning
                </Link>
              </div>
            </div>
          </nav>

          <main className="flex-grow">{children}</main>

          <footer className="bg-slate-900 text-white py-12 px-6">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="flex flex-col items-center md:items-start">
                <img
                  src="https://mace.ac.in/wp-content/uploads/2025/01/logo-2.svg"
                  alt="MACE Logo"
                  className="h-12 w-auto brightness-0 invert mb-4"
                />
                <p className="text-slate-400 text-sm">
                  Mar Athanasius College of Engineering, Kothamangalam
                </p>
              </div>
              <div className="text-center md:text-right">
                <p className="text-slate-300 font-bold mb-2">
                  Class of 2016 Alumni Association
                </p>
                <p className="text-slate-500 text-sm">© 2026 MACE 2016. All rights reserved.</p>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}